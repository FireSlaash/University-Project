/** La classe principale de ce projet */
import javax.swing.*;

public class Main {
    /** La méthode de lancement du programme */
    public static void main(String [] args) {
        JFrame maFenetre = new JFrame("Exercice 1");

        maFenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Position p = new Position();
        Affichage a = new Affichage(p);

        maFenetre.add(a);

        new ReactionClic(a,p);
        new Redessine(a);
        new Monter(p);

        maFenetre.pack();
        maFenetre.setVisible(true);



    }
}