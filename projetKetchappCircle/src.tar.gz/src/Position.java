public class Position {

    /* la position de départ */
    public static final int POS_DEPART = 20 ;

    /* la hauteur d'un saut */
    public static final int SAUT = 10;

    /* la hauteur pour monter */
    public static final int MONTE = 1;

    /* vitesse */
    private int vitesse = 1;

    /* mon attribut position */
    private int position = POS_DEPART;

    /* getter pour récupérer la position */
    public int getPosition(){
        return position;
    }

    /* Setter pour faire descendre la position */

    public void jump(){
        position += SAUT;
    }

    /* Setter pour faire monter la position */
    public void monter(){
        position -= MONTE;
    }
}
