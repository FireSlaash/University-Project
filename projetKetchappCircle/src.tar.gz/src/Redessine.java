public class Redessine extends Thread{

    /* délai de rafraichissement */
    public static final int DELAY = 50;

    /* l'affichage */
    private Affichage monAffichage;

    /* constructeur */
    public Redessine(Affichage a){
        monAffichage = a;
        this.start();
    }

    /*redéfinition de la méthode run*/
    @Override
    public void run() {
        while (true) {
            monAffichage.revalidate();
            monAffichage.repaint();
            try {
                Thread.sleep(DELAY);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
