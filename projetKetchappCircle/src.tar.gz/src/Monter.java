public class Monter extends Thread{

    /* délai de déplacement */
    public static final int DELAY = 100;

    /*la hauteur*/
    private Position maPosition;

    /* Récupérer la position */

    public Monter(Position p){
        maPosition = p;
        this.start();
    }

    @Override
    public void run() {
        while (maPosition.getPosition() > 0){
            maPosition.monter();
            try {
                Thread.sleep(DELAY);
            } catch (Exception e) {
                e.printStackTrace();

        }
    }
}
