import javax.swing.*;
import java.awt.*;

public class Affichage extends JPanel {

    public static final int LARGEUR = 600 ;
    public static final int HAUTEUR = 400;

    public static final int OVAL_LARG = 50;
    public static final int OVAL_HAUT = 100;

    public static final int X_DEPART = 20;


    /* Le modèle qui donne la position */
    private Position maPosition;

    public Affichage(Position p) {
        setPreferredSize(new Dimension(LARGEUR, HAUTEUR));
        maPosition = p;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); // Appelle la méthode de classe au dessus
        g.drawOval(X_DEPART, maPosition.getPosition(), OVAL_LARG, OVAL_HAUT);
    }

}
